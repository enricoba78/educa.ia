export default function AtividadeGerada() {
  return (
    <div>
      <h2>Atividade Gerada</h2>
      <p>Questão 1: Explique o tema.</p>
      <p>Questão 2: Dê um exemplo.</p>
    </div>
  );
}
