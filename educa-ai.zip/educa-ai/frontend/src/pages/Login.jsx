export default function Login() {
  return (
    <div>
      <h1>Educa.AI</h1>
      <input placeholder="Email" />
      <input placeholder="Senha" />
      <button>Entrar</button>
    </div>
  );
}
