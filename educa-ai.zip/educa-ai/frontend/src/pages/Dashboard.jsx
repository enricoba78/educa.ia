export default function Dashboard() {
  return (
    <div>
      <h2>Dashboard do Professor</h2>
      <button>Criar Atividade</button>
      <button>Criar Quiz</button>
      <button>Minhas Turmas</button>
    </div>
  );
}
