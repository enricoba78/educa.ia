export default function CriarAtividade() {
  return (
    <div>
      <h2>Criar Atividade com IA</h2>
      <input placeholder="Disciplina" />
      <input placeholder="Série/Ano" />
      <input placeholder="Tema" />
      <button>Gerar Atividade</button>
    </div>
  );
}
