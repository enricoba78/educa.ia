export function gerarAtividade() {
  return {
    questoes: [
      "Explique o conteúdo estudado",
      "Cite um exemplo prático"
    ]
  };
}
