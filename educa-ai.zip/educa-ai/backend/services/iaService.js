function gerarConteudoIA(tema, serie) {
  return [
    `Explique o tema ${tema}`,
    `Exemplo prático para a série ${serie}`
  ];
}

module.exports = gerarConteudoIA;
