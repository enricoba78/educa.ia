const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// Endpoint simulado de geração de atividade
app.get("/api/atividade", (req, res) => {
  res.json({
    questoes: [
      "Explique o tema estudado",
      "Dê um exemplo prático"
    ]
  });
});

app.listen(3000, () => {
  console.log("Servidor rodando na porta 3000");
});
